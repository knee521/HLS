# 实验三 全连接神经网络 FPGA 手写数字识别

工程采用 MNIST 784→32→10 全连接网络，目标板为达芬奇 A7 `xc7a35tfgg484-2`，50 MHz。已完成全部可在本机执行的软件、HLS 和 FPGA 构建工作；硬件操作按用户要求保留。

报告技术草稿为 `report/实验报告技术草稿.docx`（已渲染检查，共 8 页），同时保留 Markdown 便于核对；个人及硬件待填项均已标明。原模板未覆盖。

## 已验证结果

| 检查 | 结果 | 证据 |
|---|---|---|
| MNIST 官方测试集 10000 张 | 浮点 96.57%，定点 96.60% | `evidence/training/evaluation.json` |
| 实际综合 C 函数对整数参考 | 10000 张预测一致；100000 个分数完全一致 | `evidence/simulation/csim_baseline.csv` |
| C/RTL 协同仿真 | 24 个样本通过，含 0–9 与边界图像 | `evidence/simulation/cosim_baseline.csv` |
| HLS 流水线对照 | 51730→26364 周期，核延迟降低约 49.04% | `build/hls_*/solution1/syn/report` |
| 整机 baseline 布局布线 | DSP 2，LUT 557，FF 627；WNS +1.996 ns | `evidence/implementation/baseline` |
| 主机与 RTL | Python 单元测试、GUI 隐藏窗口启动、7 项 RTL 测试通过 | `evidence/runs` |

上述延迟为综合/仿真结果。尚无板上端到端耗时、实际手写识别率、数码管物理最右位确认或现场验收结论。GUI 几何预处理单独诊断准确率为 94.55%，不要与官方 MNIST 口径混用。

## 直接使用

在 PowerShell 中：

```powershell
Set-Location D:\HLS\code\exp3
& .\.venv\Scripts\python.exe -m host.gui
```

也可运行 `scripts/start_gui.ps1`。程序只展示 FPGA 返回结果；未连接硬件时不能识别。当前虚拟环境已经配置好。GUI 支持画板、灰度预览、加载/保存 PNG、784 字节 `.bin` 与完整 `.frame`，逐帧计时和 CSV 留证。

硬件操作请严格顺序执行 `docs/硬件操作与验收清单.md`。预备比特流在 `release/bringup`、`release/baseline`、`release/medium`、`release/fast`；`release/final` 暂为 115200 基线候选。每份包含 SHA-256 清单，均标记尚未实物验证。

## 重现环境和非硬件流程

本机：Python 3.12.1；PyTorch 2.5.1 CPU；Vivado/Vivado HLS 2018.3。依赖固定在 `requirements-lock.txt`，Python 3.12 是必需条件。

```powershell
# 仅新环境需要；已有 .venv 无需重复安装
& .\scripts\bootstrap.ps1 -Python D:\software\python312\python.exe
# 快速软件检查
& .\.venv\Scripts\python.exe -m scripts.build --stage checks
# 以下按依赖顺序执行；训练会重新生成模型和后续评估输入
& .\.venv\Scripts\python.exe -m scripts.build --stage train
& .\.venv\Scripts\python.exe -m scripts.build --stage hls --variant baseline
& .\.venv\Scripts\python.exe -m scripts.build --stage hls --variant serialized
& .\.venv\Scripts\python.exe -m scripts.build --stage rtl
& .\.venv\Scripts\python.exe -m scripts.build --stage implement
& .\.venv\Scripts\python.exe -m scripts.finalize_release
```

每条命令必须返回 0 才继续下一条；PowerShell 默认不会因外部程序非零退出自动停止。可单独使用 `--configuration baseline|medium|fast|bringup` 和 `--rightmost-index 0..5` 重建硬件候选。`--stage all` 包含重新训练，默认只跑 baseline HLS；串行对照另执行上面的 serialized 命令。

工具绝对路径集中在 `scripts/build.py`、相关 Tcl 与 IP 打包脚本。换机器应先按新安装位置修改，不能直接把 2018.3 生成文件跨版本当作已验证构建。HLS 日期溢出由项目内打包元数据修复处理，详见实施记录。

## 工程组织与维护

| 目录 | 职责 |
|---|---|
| `common` | 协议、图像预处理、整数模型、配置与文件校验 |
| `train` / `model` | 确定性训练、量化、评估 / 冻结权重和数值界限 |
| `host` | GUI、串口事务、故障注入、数据集测量和统计 |
| `hls` | 同一份可综合推理 C++、权重、C 测试和 HLS Tcl |
| `rtl` / `constraints` | UART、状态机、显示、顶层 / 实物引脚及 20 ns 时钟约束 |
| `tests` / `sim` | Python 自动测试 / RTL 自检测试台 |
| `scripts` | 可重建脚本；`program_device.tcl` 仅由用户上板时运行 |
| `data/vectors` | 冻结的测试图、标签、整数分数和协同仿真样本 |
| `evidence` | 原始训练、构建、仿真、时序、资源及 AI 执行记录 |
| `release` / `report` | 比特流与哈希清单 / 报告技术草稿和验收补录资料 |

工程采用分层模块、固定协议、配置校验、异常返回、单事务互斥、超时恢复、确定性种子、源文件/模型/比特流哈希和可重建脚本。原始实验资料未覆盖。`build` 是生成目录；不要删除模型、原始 CSV 或唯一的已验收发布文件。当前目录未初始化 Git，源码快照以 `evidence/source_hashes.json` 标识；运行日志是过程证据，不以“编译成功”代替仿真或上板。

先读 `docs/实施记录与偏差.md` 中的放行边界，再补齐个人报告的独立心得、真实 AI 使用确认和教师签字。不得把草稿直接作为已完成验收的个人报告提交。
